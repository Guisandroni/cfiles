#include <stdio.h>

int main(void)
{	float valor;

	valor = 5 / 2;
	printf("%f\n", valor);

	return 0;
}
